﻿using System;

namespace inventoryData
{
    public class Class1
    {
    }
}
