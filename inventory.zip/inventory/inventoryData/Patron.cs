﻿namespace inventoryData
{
    public class Patron
    {
    }
}