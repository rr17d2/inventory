﻿using System;
namespace inventoryData
{
    public class Models
    {
        public Models()
        {
        }
    }
}
