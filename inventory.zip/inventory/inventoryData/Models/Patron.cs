﻿using System;
namespace inventoryData.Models
{
    public class Patron
    {
        public Patron()
        {
        }
    }
}
